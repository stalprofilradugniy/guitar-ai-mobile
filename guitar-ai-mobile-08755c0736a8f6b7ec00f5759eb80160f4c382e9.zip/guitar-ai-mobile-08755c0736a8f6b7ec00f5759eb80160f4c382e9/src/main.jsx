import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/mobile.css'; // Link main CSS

// Optional: Register service worker if needed
// import './service-worker';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
