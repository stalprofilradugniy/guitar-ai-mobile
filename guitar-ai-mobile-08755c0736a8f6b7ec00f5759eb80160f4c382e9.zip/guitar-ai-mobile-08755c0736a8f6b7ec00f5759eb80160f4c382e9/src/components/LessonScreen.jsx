import React from 'react';

function LessonScreen() {
  return (
    <div>
      <h1>Lesson Screen</h1>
      {/* Add your lesson screen content here */}
    </div>
  );
}

export default LessonScreen;
