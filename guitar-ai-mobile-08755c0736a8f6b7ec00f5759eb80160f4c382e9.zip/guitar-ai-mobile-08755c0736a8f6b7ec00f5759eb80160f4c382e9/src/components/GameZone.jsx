import React from 'react';

function GameZone() {
  return (
    <div>
      <h2>Game Zone</h2>
      {/* Add game logic and UI here */}
    </div>
  );
}

export default GameZone;
