import React from 'react';

function HomeScreen() {
  return (
    <div>
      <h1>Home Screen</h1>
      {/* Add your home screen content here */}
    </div>
  );
}

export default HomeScreen;
