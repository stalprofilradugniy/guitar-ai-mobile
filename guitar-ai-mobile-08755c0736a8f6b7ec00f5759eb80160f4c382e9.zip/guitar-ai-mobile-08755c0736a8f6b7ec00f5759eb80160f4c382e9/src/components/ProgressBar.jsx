import React from 'react';

function ProgressBar({ progress }) {
  return (
    <div>
      <h4>Progress Bar</h4>
      <progress value={progress} max="100"></progress>
      {/* Add progress bar UI here */}
    </div>
  );
}

export default ProgressBar;
